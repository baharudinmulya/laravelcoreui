(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[75],{

/***/ "../coreui/src/views/widgets/Widgets.vue":
/*!***********************************************!*\
  !*** ../coreui/src/views/widgets/Widgets.vue ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Widgets.vue?vue&type=template&id=5af24715& */ "../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715&");
/* harmony import */ var _Widgets_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Widgets.vue?vue&type=script&lang=js& */ "../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Widgets_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/widgets/Widgets.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js&":
/*!************************************************************************!*\
  !*** ../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js& ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Widgets_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Widgets.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Widgets_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715&":
/*!******************************************************************************!*\
  !*** ../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715& ***!
  \******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Widgets.vue?vue&type=template&id=5af24715& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Widgets_vue_vue_type_template_id_5af24715___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/widgets/Widgets.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WidgetsBrand__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WidgetsBrand */ "../coreui/src/views/widgets/WidgetsBrand.vue");
/* harmony import */ var _WidgetsDropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./WidgetsDropdown */ "../coreui/src/views/widgets/WidgetsDropdown.vue");
/* harmony import */ var _charts_index_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../charts/index.js */ "../coreui/src/views/charts/index.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Widgets',
  components: {
    CChartLineSimple: _charts_index_js__WEBPACK_IMPORTED_MODULE_2__["CChartLineSimple"],
    CChartBarSimple: _charts_index_js__WEBPACK_IMPORTED_MODULE_2__["CChartBarSimple"],
    WidgetsBrand: _WidgetsBrand__WEBPACK_IMPORTED_MODULE_0__["default"],
    WidgetsDropdown: _WidgetsDropdown__WEBPACK_IMPORTED_MODULE_1__["default"]
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/widgets/Widgets.vue?vue&type=template&id=5af24715& ***!
  \************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetProgress",
                { attrs: { footer: "Lorem ipsum dolor sit amet enim." } },
                [
                  _c("div", { staticClass: "h4 m-0" }, [_vm._v("89.9%")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "card-header-actions" }, [
                    _c(
                      "a",
                      {
                        staticClass: "card-header-action position-absolute",
                        staticStyle: { right: "5px", top: "5px" },
                        attrs: {
                          href: "https://coreui.io/vue/docs/components/widgets",
                          rel: "noreferrer noopener",
                          target: "_blank"
                        }
                      },
                      [
                        _c("small", { staticClass: "text-muted" }, [
                          _vm._v("docs")
                        ])
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", [_vm._v("Lorem ipsum...")]),
                  _vm._v(" "),
                  _c("CProgress", {
                    staticClass: "progress-xs my-3 mb-0",
                    attrs: { color: "success", value: 25 }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "12.124",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "info",
                  value: 25
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "$98.111,00",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "warning",
                  value: 25
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "2 TB",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "danger",
                  value: 25
                }
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "89.9%",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "success",
                  inverse: "",
                  value: 25
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "12.124",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "info",
                  inverse: "",
                  value: 25
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "$98.111,00",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "warning",
                  inverse: "",
                  value: 25
                }
              })
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", lg: "3" } },
            [
              _c("CWidgetProgress", {
                attrs: {
                  header: "2 TB",
                  text: "Lorem ipsum...",
                  footer: "Lorem ipsum dolor sit amet enim.",
                  color: "danger",
                  inverse: "",
                  value: 25
                }
              })
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "primary"
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-settings", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: { header: "$1.999,50", text: "Income", color: "info" }
                },
                [_c("CIcon", { attrs: { name: "cil-laptop", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "warning"
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-moon", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "danger"
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-bell", width: "24" } })],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "primary",
                    "icon-padding": false
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-settings", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "info",
                    "icon-padding": false
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-laptop", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "warning",
                    "icon-padding": false
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-moon", width: "24" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "3" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "danger",
                    "icon-padding": false
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-bell", width: "24" } })],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "4" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "primary",
                    "icon-padding": false
                  }
                },
                [
                  _c("CIcon", {
                    staticClass: "mx-5 ",
                    attrs: { name: "cil-settings", width: "24" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "4" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "info",
                    "icon-padding": false
                  }
                },
                [
                  _c("CIcon", {
                    staticClass: "mx-5 ",
                    attrs: { name: "cil-laptop", width: "24" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", sm: "6", lg: "4" } },
            [
              _c(
                "CWidgetIcon",
                {
                  attrs: {
                    header: "$1.999,50",
                    text: "Income",
                    color: "warning",
                    "icon-padding": false
                  },
                  scopedSlots: _vm._u([
                    {
                      key: "footer",
                      fn: function() {
                        return [
                          _c(
                            "CCardFooter",
                            { staticClass: "card-footer px-3 py-2" },
                            [
                              _c(
                                "CLink",
                                {
                                  staticClass:
                                    "font-weight-bold font-xs btn-block text-muted",
                                  attrs: { href: "https://coreui.io/" }
                                },
                                [
                                  _vm._v(
                                    "\n              View more\n              "
                                  ),
                                  _c("CIcon", {
                                    staticClass: "float-right",
                                    attrs: {
                                      name: "cil-arrowRight",
                                      width: "16"
                                    }
                                  })
                                ],
                                1
                              )
                            ],
                            1
                          )
                        ]
                      },
                      proxy: true
                    }
                  ])
                },
                [
                  _c("CIcon", {
                    staticClass: "mx-5 ",
                    attrs: { name: "cil-moon", width: "24" }
                  })
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("WidgetsBrand", { attrs: { noCharts: "" } }),
      _vm._v(" "),
      _c("WidgetsBrand"),
      _vm._v(" "),
      _c(
        "CCardGroup",
        { staticClass: "mb-4" },
        [
          _c(
            "CWidgetProgressIcon",
            { attrs: { header: "87.500", text: "Visitors", color: "info" } },
            [_c("CIcon", { attrs: { name: "cil-people", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            { attrs: { header: "385", text: "New Clients", color: "success" } },
            [_c("CIcon", { attrs: { name: "cil-userFollow", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: { header: "1238", text: "Products sold", color: "warning" }
            },
            [_c("CIcon", { attrs: { name: "cil-basket", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            { attrs: { header: "28%", text: "Returning Visitors" } },
            [_c("CIcon", { attrs: { name: "cil-chartPie", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: { header: "5:34:11", text: "Avg. Time", color: "danger" }
            },
            [_c("CIcon", { attrs: { name: "cil-speedometer", height: "36" } })],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCardGroup",
        { staticClass: "mb-4" },
        [
          _c(
            "CWidgetProgressIcon",
            {
              attrs: {
                header: "87.500",
                text: "Visitors",
                color: "info",
                inverse: ""
              }
            },
            [_c("CIcon", { attrs: { name: "cil-people", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: {
                header: "385",
                text: "New Clients",
                color: "success",
                inverse: ""
              }
            },
            [_c("CIcon", { attrs: { name: "cil-userFollow", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: {
                header: "1238",
                text: "Products sold",
                color: "warning",
                inverse: ""
              }
            },
            [_c("CIcon", { attrs: { name: "cil-basket", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: {
                header: "28%",
                text: "Returning Visitors",
                color: "primary",
                inverse: ""
              }
            },
            [_c("CIcon", { attrs: { name: "cil-chartPie", height: "36" } })],
            1
          ),
          _vm._v(" "),
          _c(
            "CWidgetProgressIcon",
            {
              attrs: {
                header: "5:34:11",
                text: "Avg. Time",
                color: "danger",
                inverse: ""
              }
            },
            [_c("CIcon", { attrs: { name: "cil-speedometer", height: "36" } })],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: { header: "87.500", text: "Visitors", color: "info" }
                },
                [_c("CIcon", { attrs: { name: "cil-people", height: "36" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "385",
                    text: "New Clients",
                    color: "success"
                  }
                },
                [
                  _c("CIcon", {
                    attrs: { name: "cil-userFollow", height: "36" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "1238",
                    text: "Products sold",
                    color: "warning"
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-basket", height: "36" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "28%",
                    text: "Returning Visitors",
                    color: "primary"
                  }
                },
                [
                  _c("CIcon", { attrs: { name: "cil-chartPie", height: "36" } })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "5:34:11",
                    text: "Avg. Time",
                    color: "danger"
                  }
                },
                [
                  _c("CIcon", {
                    attrs: { name: "cil-speedometer", height: "36" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                { attrs: { header: "972", text: "comments", color: "info" } },
                [_c("CIcon", { attrs: { name: "cil-speech", height: "36" } })],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "87.500",
                    text: "Visitors",
                    color: "info",
                    inverse: ""
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-people", height: "36" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "385",
                    text: "New Clients",
                    color: "success",
                    inverse: ""
                  }
                },
                [
                  _c("CIcon", {
                    attrs: { name: "cil-userFollow", height: "36" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "1238",
                    text: "Products sold",
                    color: "warning",
                    inverse: ""
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-basket", height: "36" } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "28%",
                    text: "Returning Visitors",
                    color: "primary",
                    inverse: ""
                  }
                },
                [
                  _c("CIcon", { attrs: { name: "cil-chartPie", height: "36" } })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "5:34:11",
                    text: "Avg. Time",
                    color: "danger",
                    inverse: ""
                  }
                },
                [
                  _c("CIcon", {
                    attrs: { name: "cil-speedometer", height: "36" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "6", md: "2" } },
            [
              _c(
                "CWidgetProgressIcon",
                {
                  attrs: {
                    header: "972",
                    text: "comments",
                    color: "info",
                    inverse: ""
                  }
                },
                [_c("CIcon", { attrs: { name: "cil-speech", height: "36" } })],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("WidgetsDropdown"),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartLineSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "border-color": "danger" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartLineSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "border-color": "primary" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartLineSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "border-color": "success" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartBarSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "background-color": "danger" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartBarSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "background-color": "primary" }
                  })
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { sm: "4", lg: "2" } },
            [
              _c(
                "CWidgetSimple",
                { attrs: { header: "title", text: "1,123" } },
                [
                  _c("CChartBarSimple", {
                    staticStyle: { height: "40px" },
                    attrs: { "background-color": "success" }
                  })
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);