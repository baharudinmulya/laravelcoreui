(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[48],{

/***/ "../coreui/src/views/menuElements/CreateMenuElement.vue":
/*!**************************************************************!*\
  !*** ../coreui/src/views/menuElements/CreateMenuElement.vue ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CreateMenuElement.vue?vue&type=template&id=3109ff92& */ "../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92&");
/* harmony import */ var _CreateMenuElement_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CreateMenuElement.vue?vue&type=script&lang=js& */ "../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _CreateMenuElement_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__["render"],
  _CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/menuElements/CreateMenuElement.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js&":
/*!***************************************************************************************!*\
  !*** ../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateMenuElement_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./CreateMenuElement.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateMenuElement_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92&":
/*!*********************************************************************************************!*\
  !*** ../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92& ***!
  \*********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./CreateMenuElement.vue?vue&type=template&id=3109ff92& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateMenuElement_vue_vue_type_template_id_3109ff92___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "../coreui/node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'CreateMenuElement',
  data: function data() {
    return {
      role: [],
      menulist: [],
      parents: [],
      types: [{
        label: 'Link',
        value: 'link'
      }, {
        label: 'Title',
        value: 'title'
      }, {
        label: 'Dropdown',
        value: 'dropdown'
      }],
      menuelement: {
        menu: 0,
        name: '',
        role: [],
        type: 'link',
        href: '',
        icon: '',
        parent: 0
      },
      message: '',
      dismissSecs: 7,
      dismissCountDown: 0,
      showDismissibleAlert: false,
      divHref: false,
      divDropdownParent: false,
      divIcon: false
    };
  },
  methods: {
    goBack: function goBack() {
      this.$router.go(-1); // this.$router.replace({path: '/users'})
    },
    selectRadioSelectRole: function selectRadioSelectRole(role) {
      var temp = this.menuelement.role.indexOf(role);

      if (temp > -1) {
        this.menuelement.role.splice(temp, 1);
      } else {
        this.menuelement.role.push(role);
      }
    },
    changeType: function changeType() {
      var temp = this.menuelement.type;

      if (temp == 'title') {
        this.divHref = false;
        this.divDropdownParent = false;
        this.divIcon = false;
      } else if (temp == 'link') {
        this.divHref = true;
        this.divDropdownParent = true;
        this.divIcon = true;
      } else {
        this.divHref = false;
        this.divDropdownParent = true;
        this.divIcon = true;
      }
    },
    updateSelectParent: function updateSelectParent() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/menu/element/get-parents?token=' + localStorage.getItem("api_token") + '&menu=' + self.menuelement.menu).then(function (response) {
        self.parents = [{
          label: 'Has no parent',
          value: 'none'
        }];

        for (var i = 0; i < response.data.length; i++) {
          self.parents.push(response.data[i]);
        }
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: 'login'
        });
      });
    },
    store: function store() {
      var self = this;
      console.log(self.menuelement);
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post(this.$apiAdress + '/api/menu/element/store?token=' + localStorage.getItem("api_token"), self.menuelement).then(function (response) {
        self.name = '';
        self.message = 'Successfully created menu element.';
        self.showAlert();
      })["catch"](function (error) {
        if (error.response.data.message == 'The given data was invalid.') {
          self.message = '';

          for (var key in error.response.data.errors) {
            if (error.response.data.errors.hasOwnProperty(key)) {
              self.message += error.response.data.errors[key][0] + '  ';
            }
          }

          self.showAlert();
        } else {
          console.log(error);
          self.$router.push({
            path: 'login'
          });
        }
      });
    },
    countDownChanged: function countDownChanged(dismissCountDown) {
      this.dismissCountDown = dismissCountDown;
    },
    showAlert: function showAlert() {
      this.dismissCountDown = this.dismissSecs;
    },
    getData: function getData() {
      var self = this;
      axios__WEBPACK_IMPORTED_MODULE_0___default.a.get(this.$apiAdress + '/api/menu/element/create?token=' + localStorage.getItem("api_token") + '&id=' + self.$route.params.menu).then(function (response) {
        self.role = response.data.roles;
        self.menulist = response.data.menulist;
      })["catch"](function (error) {
        console.log(error);
        self.$router.push({
          path: '/login'
        });
      });
    }
  },
  mounted: function mounted() {
    this.getData();
    this.menuelement.menu = this.$route.params.menu;
    this.updateSelectParent();
    this.changeType();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92&":
/*!***************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/menuElements/CreateMenuElement.vue?vue&type=template&id=3109ff92& ***!
  \***************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "CRow",
    [
      _c(
        "CCol",
        { attrs: { col: "12", lg: "6" } },
        [
          _c(
            "CCard",
            { attrs: { "no-header": "" } },
            [
              _c(
                "CCardBody",
                [
                  _c("h3", [
                    _vm._v("\n          Create Menu Element\n        ")
                  ]),
                  _vm._v(" "),
                  _c(
                    "CAlert",
                    {
                      attrs: {
                        show: _vm.dismissCountDown,
                        color: "primary",
                        fade: ""
                      },
                      on: {
                        "update:show": function($event) {
                          _vm.dismissCountDown = $event
                        }
                      }
                    },
                    [
                      _vm._v(
                        "\n          (" +
                          _vm._s(_vm.dismissCountDown) +
                          ") " +
                          _vm._s(_vm.message) +
                          "\n        "
                      )
                    ]
                  ),
                  _vm._v(" "),
                  _c("CSelect", {
                    attrs: {
                      label: "Menu",
                      value: _vm.menuelement.menu,
                      plain: true,
                      options: _vm.menulist
                    },
                    on: {
                      "update:value": [
                        function($event) {
                          return _vm.$set(_vm.menuelement, "menu", $event)
                        },
                        function($event) {
                          return _vm.updateSelectParent()
                        }
                      ]
                    }
                  }),
                  _vm._v(" "),
                  _c("p", [_vm._v("Roles")]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "m-3" },
                    _vm._l(_vm.role, function(rol) {
                      return _c("CInputCheckbox", {
                        key: rol,
                        attrs: { label: rol, name: "selectRoles" },
                        on: {
                          "update:checked": function($event) {
                            return _vm.selectRadioSelectRole(rol)
                          }
                        }
                      })
                    }),
                    1
                  ),
                  _vm._v(" "),
                  _c("CInput", {
                    attrs: { label: "Name", type: "text", placeholder: "Name" },
                    model: {
                      value: _vm.menuelement.name,
                      callback: function($$v) {
                        _vm.$set(_vm.menuelement, "name", $$v)
                      },
                      expression: "menuelement.name"
                    }
                  }),
                  _vm._v(" "),
                  _c("CSelect", {
                    attrs: {
                      label: "Type",
                      value: _vm.menuelement.type,
                      plain: true,
                      options: _vm.types
                    },
                    on: {
                      "update:value": [
                        function($event) {
                          return _vm.$set(_vm.menuelement, "type", $event)
                        },
                        function($event) {
                          return _vm.changeType()
                        }
                      ]
                    }
                  }),
                  _vm._v(" "),
                  _c("p", [_vm._v("Other")]),
                  _vm._v(" "),
                  _vm.divHref
                    ? _c(
                        "div",
                        [
                          _c("CInput", {
                            attrs: {
                              label: "Href",
                              type: "text",
                              placeholder: "Href"
                            },
                            model: {
                              value: _vm.menuelement.href,
                              callback: function($$v) {
                                _vm.$set(_vm.menuelement, "href", $$v)
                              },
                              expression: "menuelement.href"
                            }
                          })
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.divDropdownParent
                    ? _c(
                        "div",
                        [
                          _c("CSelect", {
                            attrs: {
                              label: "Dropdown parent",
                              value: _vm.menuelement.parent,
                              plain: true,
                              options: _vm.parents
                            },
                            on: {
                              "update:value": function($event) {
                                return _vm.$set(
                                  _vm.menuelement,
                                  "parent",
                                  $event
                                )
                              }
                            }
                          })
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.divIcon
                    ? _c(
                        "div",
                        [
                          _vm._v(
                            "\n            Icon - Find icon class in: \n            "
                          ),
                          _c(
                            "a",
                            {
                              attrs: {
                                href:
                                  "https://coreui.io/docs/icons/icons-list/#coreui-icons-free-502-icons",
                                target: "_blank"
                              }
                            },
                            [
                              _vm._v(
                                "\n              CoreUI icons documentation\n            "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c("br"),
                          _vm._v(" "),
                          _c("CInput", {
                            attrs: {
                              type: "text",
                              placeholder:
                                "CoreUI Icon class - example: cil-bell"
                            },
                            model: {
                              value: _vm.menuelement.icon,
                              callback: function($$v) {
                                _vm.$set(_vm.menuelement, "icon", $$v)
                              },
                              expression: "menuelement.icon"
                            }
                          })
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _c(
                    "CButton",
                    {
                      attrs: { color: "primary" },
                      on: {
                        click: function($event) {
                          return _vm.store()
                        }
                      }
                    },
                    [_vm._v("Create")]
                  ),
                  _vm._v(" "),
                  _c(
                    "CButton",
                    { attrs: { color: "primary" }, on: { click: _vm.goBack } },
                    [_vm._v("Back")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);