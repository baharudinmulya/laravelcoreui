(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[71],{

/***/ "../coreui/src/views/theme/Typography.vue":
/*!************************************************!*\
  !*** ../coreui/src/views/theme/Typography.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Typography.vue?vue&type=template&id=7ed44e5f& */ "../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f&");
/* harmony import */ var _Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Typography.vue?vue&type=script&lang=js& */ "../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/theme/Typography.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Typography.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f&":
/*!*******************************************************************************!*\
  !*** ../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Typography.vue?vue&type=template&id=7ed44e5f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Typography_vue_vue_type_template_id_7ed44e5f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/theme/Typography.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Typography'
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/theme/Typography.vue?vue&type=template&id=7ed44e5f& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._v("\n      Headings\n    ")
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
          _c("p", [
            _vm._v(
              "Documentation and examples for Bootstrap typography,\n        including global settings, headings, body text, lists, and more."
            )
          ]),
          _vm._v(" "),
          _c("table", { staticClass: "table" }, [
            _c("thead", [
              _c("tr", [
                _c("th", [_vm._v("Heading")]),
                _vm._v(" "),
                _c("th", [_vm._v("Example")])
              ])
            ]),
            _vm._v(" "),
            _c("tbody", [
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h1></h1>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h1" }, [
                    _vm._v("h1. Bootstrap heading")
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h2></h2>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h2" }, [
                    _vm._v("h2. Bootstrap heading")
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h3></h3>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h3" }, [
                    _vm._v("h3. Bootstrap heading")
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h4></h4>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h4" }, [
                    _vm._v("h4. Bootstrap heading")
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h5></h5>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h5" }, [
                    _vm._v("h5. Bootstrap heading")
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("tr", [
                _c("td", [
                  _c("p", [
                    _c("code", { staticClass: "highlighter-rouge" }, [
                      _vm._v("\n                  <h6></h6>\n                ")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("td", [
                  _c("span", { staticClass: "h6" }, [
                    _vm._v("h6. Bootstrap heading")
                  ])
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._v("\n      Headings\n    ")
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
          _c("p", [
            _c("code", { staticClass: "highlighter-rouge" }, [_vm._v(".h1")]),
            _vm._v(" through\n        "),
            _c("code", { staticClass: "highlighter-rouge" }, [_vm._v(".h6")]),
            _vm._v(
              "\n        classes are also available, for when you want to match the font\n        styling of a heading but cannot use the associated HTML element.\n      "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "bd-example" }, [
            _c("p", { staticClass: "h1" }, [_vm._v("h1. Bootstrap heading")]),
            _vm._v(" "),
            _c("p", { staticClass: "h2" }, [_vm._v("h2. Bootstrap heading")]),
            _vm._v(" "),
            _c("p", { staticClass: "h3" }, [_vm._v("h3. Bootstrap heading")]),
            _vm._v(" "),
            _c("p", { staticClass: "h4" }, [_vm._v("h4. Bootstrap heading")]),
            _vm._v(" "),
            _c("p", { staticClass: "h5" }, [_vm._v("h5. Bootstrap heading")]),
            _vm._v(" "),
            _c("p", { staticClass: "h6" }, [_vm._v("h6. Bootstrap heading")])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._v("\n      Display headings\n    ")
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
          _c("p", [
            _vm._v(
              "\n        Traditional heading elements are designed to work best in the meat\n        of your page content. When you need a heading to stand out,\n        consider using a "
            ),
            _c("strong", [_vm._v("display heading")]),
            _vm._v(
              "—a larger,\n         slightly more opinionated heading style.\n      "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "bd-example bd-example-type" }, [
            _c("table", { staticClass: "table" }, [
              _c("tbody", [
                _c("tr", [
                  _c("td", [
                    _c("span", { staticClass: "display-1" }, [
                      _vm._v("Display 1")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("tr", [
                  _c("td", [
                    _c("span", { staticClass: "display-2" }, [
                      _vm._v("Display 2")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("tr", [
                  _c("td", [
                    _c("span", { staticClass: "display-3" }, [
                      _vm._v("Display 3")
                    ])
                  ])
                ]),
                _vm._v(" "),
                _c("tr", [
                  _c("td", [
                    _c("span", { staticClass: "display-4" }, [
                      _vm._v("Display 4")
                    ])
                  ])
                ])
              ])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._v("\n      Inline text elements\n    ")
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
          _c("p", [
            _vm._v(
              "\n        Traditional heading elements are designed to work best in the meat\n        of your page content. When you need a heading to stand out,\n        consider using a "
            ),
            _c("strong", [_vm._v("display heading")]),
            _vm._v(
              "—a larger,\n        slightly more opinionated heading style.\n      "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "bd-example" }, [
            _c("p", [
              _vm._v("You can use the mark tag to "),
              _c("mark", [_vm._v("highlight")]),
              _vm._v(" text.")
            ]),
            _vm._v(" "),
            _c("p", [
              _c("del", [
                _vm._v(
                  "\n          This line of text is meant to be treated as deleted text.\n        "
                )
              ])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("s", [
                _vm._v(
                  "\n          This line of text is meant to be treated as no longer accurate.\n        "
                )
              ])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("ins", [
                _vm._v(
                  "\n          This line of text is meant to be treated as an addition to the document.\n        "
                )
              ])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("u", [_vm._v("This line of text will render as underlined")])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("small", [
                _vm._v(
                  "\n          This line of text is meant to be treated as fine print.\n        "
                )
              ])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("strong", [_vm._v("This line rendered as bold text.")])
            ]),
            _vm._v(" "),
            _c("p", [
              _c("em", [_vm._v("This line rendered as italicized text.")])
            ])
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "card" }, [
        _c("div", { staticClass: "card-header" }, [
          _vm._v("\n      Description list alignment\n    ")
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "card-body" }, [
          _c("p", [
            _vm._v(
              "\n        Align terms and descriptions horizontally by using our grid system’s\n        predefined classes (or semantic mixins). For longer terms, you can\n        optionally add a "
            ),
            _c("code", { staticClass: "highlighter-rouge" }, [
              _vm._v(".text-truncate")
            ]),
            _vm._v(
              "\n        class to truncate the text with an ellipsis.\n      "
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "bd-example" }, [
            _c("dl", { staticClass: "row" }, [
              _c("dt", { staticClass: "col-sm-3" }, [
                _vm._v("Description lists")
              ]),
              _vm._v(" "),
              _c("dd", { staticClass: "col-sm-9" }, [
                _vm._v(
                  "\n            A description list is perfect for defining terms.\n          "
                )
              ]),
              _vm._v(" "),
              _c("dt", { staticClass: "col-sm-3" }, [_vm._v("Euismod")]),
              _vm._v(" "),
              _c("dd", { staticClass: "col-sm-9" }, [
                _c("p", [
                  _vm._v(
                    "Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit."
                  )
                ]),
                _vm._v(" "),
                _c("p", [
                  _vm._v("Donec id elit non mi porta gravida at eget metus.")
                ])
              ]),
              _vm._v(" "),
              _c("dt", { staticClass: "col-sm-3" }, [
                _vm._v("Malesuada porta")
              ]),
              _vm._v(" "),
              _c("dd", { staticClass: "col-sm-9" }, [
                _vm._v(
                  "\n            Etiam porta sem malesuada magna mollis euismod.\n          "
                )
              ]),
              _vm._v(" "),
              _c("dt", { staticClass: "col-sm-3 text-truncate" }, [
                _vm._v("Truncated term is truncated")
              ]),
              _vm._v(" "),
              _c("dd", { staticClass: "col-sm-9" }, [
                _vm._v(
                  "\n            Fusce dapibus, tellus ac cursus commodo, tortor mauris\n            condimentum nibh, ut fermentum massa justo sit amet risus.\n          "
                )
              ]),
              _vm._v(" "),
              _c("dt", { staticClass: "col-sm-3" }, [_vm._v("Nesting")]),
              _vm._v(" "),
              _c("dd", { staticClass: "col-sm-9" }, [
                _c("dl", { staticClass: "row" }, [
                  _c("dt", { staticClass: "col-sm-4" }, [
                    _vm._v("Nested definition list")
                  ]),
                  _vm._v(" "),
                  _c("dd", { staticClass: "col-sm-8" }, [
                    _vm._v(
                      "\n                Aenean posuere, tortor sed cursus feugiat, nunc augue nunc.\n              "
                    )
                  ])
                ])
              ])
            ])
          ])
        ])
      ])
    ])
  }
]
render._withStripped = true



/***/ })

}]);