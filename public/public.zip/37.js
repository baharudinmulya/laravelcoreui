(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[37],{

/***/ "../coreui/src/views/buttons/Dropdowns.vue":
/*!*************************************************!*\
  !*** ../coreui/src/views/buttons/Dropdowns.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Dropdowns.vue?vue&type=template&id=2095533a& */ "../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a&");
/* harmony import */ var _Dropdowns_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Dropdowns.vue?vue&type=script&lang=js& */ "../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Dropdowns_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/buttons/Dropdowns.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdowns_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Dropdowns.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdowns_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a&":
/*!********************************************************************************!*\
  !*** ../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a& ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Dropdowns.vue?vue&type=template&id=2095533a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdowns_vue_vue_type_template_id_2095533a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/buttons/Dropdowns.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Dropdowns'
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/buttons/Dropdowns.vue?vue&type=template&id=2095533a& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Bootstrap Dropdown")]),
                      _vm._v(" "),
                      _c("div", { staticClass: "card-header-actions" }, [
                        _c(
                          "a",
                          {
                            staticClass: "card-header-action",
                            attrs: {
                              href:
                                "https://coreui.io/vue/docs/components/dropdown",
                              rel: "noreferrer noopener",
                              target: "_blank"
                            }
                          },
                          [
                            _c("small", { staticClass: "text-muted" }, [
                              _vm._v("docs")
                            ])
                          ]
                        )
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CCardBody", [
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              "toggler-text": "Dropdown Button",
                              color: "secondary"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("First Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Second Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Third Action")]),
                            _vm._v(" "),
                            _c("CDropdownDivider"),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ]),
                            _vm._v(" "),
                            _c("CDropdownItem", { attrs: { disabled: "" } }, [
                              _vm._v("Disabled action")
                            ])
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              "toggler-text": "Dropdown with divider",
                              color: "secondary"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("First item")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Second item")]),
                            _vm._v(" "),
                            _c("CDropdownDivider"),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Separated Item")])
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              "toggler-text": "Dropdown with header",
                              color: "secondary"
                            }
                          },
                          [
                            _c("CDropdownHeader", [_vm._v("Dropdown header")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("First item")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Second Item")])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Dropdown ")]),
                      _vm._v(" "),
                      _c("small", [_vm._v("positioning")])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CCardBody", [
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2 d-inline-block",
                            attrs: {
                              "toggler-text": "Left align",
                              color: "primary"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Something else here")])
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2 d-inline-block",
                            attrs: {
                              placement: "bottom-end",
                              "toggler-text": "Right align",
                              color: "primary"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Something else here")])
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              "toggler-text": "Drop-Up",
                              color: "info",
                              placement: "top-start"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Something else here")])
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              color: "secondary",
                              offset: [10, 5],
                              "toggler-text": "Offset Dropdown"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Something else here")])
                          ],
                          1
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              color: "secondary",
                              split: "",
                              "toggler-text": "Split Dropdown"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Dropdown ")]),
                      _vm._v(" "),
                      _c("small", [_vm._v("hidden caret")])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CCardBody", [
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            attrs: { color: "link", size: "lg", caret: false },
                            scopedSlots: _vm._u([
                              {
                                key: "toggler-content",
                                fn: function() {
                                  return [
                                    _vm._v("\n                🔍"),
                                    _c("span", { staticClass: "sr-only" }, [
                                      _vm._v("Search")
                                    ])
                                  ]
                                },
                                proxy: true
                              }
                            ])
                          },
                          [
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Dropdown ")]),
                      _vm._v(" "),
                      _c("small", [_vm._v("sizing")])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CCardBody", [
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2 d-inline-block",
                            attrs: {
                              color: "secondary",
                              size: "lg",
                              "toggler-text": "Large"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Something else here")])
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              color: "secondary",
                              size: "lg",
                              split: "",
                              "toggler-text": "Large Split"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ])
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c("br"),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2 d-inline-block",
                            attrs: {
                              color: "secondary",
                              size: "sm",
                              "toggler-text": "Small"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ])
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              color: "secondary",
                              size: "sm",
                              split: "",
                              "toggler-text": "Small Split"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Another action")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("Something else here...")
                            ])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CRow",
        [
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Dropdown ")]),
                      _vm._v(" "),
                      _c("small", [_vm._v("headers and accessibility")])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("CCardBody", [
                    _c(
                      "div",
                      [
                        _c(
                          "CDropdown",
                          {
                            staticClass: "m-2",
                            attrs: {
                              "toggler-text": "Dropdown ARIA",
                              color: "primary"
                            }
                          },
                          [
                            _c(
                              "div",
                              { attrs: { role: "group" } },
                              [
                                _c("CDropdownHeader", [_vm._v("Groups")]),
                                _vm._v(" "),
                                _c("CDropdownItem", [_vm._v("Add")]),
                                _vm._v(" "),
                                _c("CDropdownItem", [_vm._v("Delete")])
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              { attrs: { role: "group" } },
                              [
                                _c("CDropdownHeader", [_vm._v("Users")]),
                                _vm._v(" "),
                                _c("CDropdownItem", [_vm._v("Add")]),
                                _vm._v(" "),
                                _c("CDropdownItem", [_vm._v("Delete")])
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c("CDropdownDivider"),
                            _vm._v(" "),
                            _c("CDropdownItem", [
                              _vm._v("\n                Something "),
                              _c("strong", [_vm._v("not")]),
                              _vm._v(" associated with user\n              ")
                            ])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCol",
            { attrs: { col: "12", md: "6" } },
            [
              _c(
                "CCard",
                [
                  _c(
                    "CCardHeader",
                    [
                      _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                      _vm._v(" "),
                      _c("strong", [_vm._v(" Dropdown ")]),
                      _vm._v(" "),
                      _c("small", [_c("code", [_vm._v("color")])])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "CCardBody",
                    [
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Primary",
                            color: "primary"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Secondary",
                            color: "secondary"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Success",
                            color: "success"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Warning",
                            color: "warning"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Danger",
                            color: "danger"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Info",
                            color: "info"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Light",
                            color: "light"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Dark",
                            color: "dark"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "m-0 d-inline-block",
                          attrs: {
                            size: "sm",
                            "toggler-text": "Link",
                            color: "link"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("First Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Second Action")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Third Action")])
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);