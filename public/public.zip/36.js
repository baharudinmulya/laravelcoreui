(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[36],{

/***/ "../coreui/src/views/buttons/ButtonGroups.vue":
/*!****************************************************!*\
  !*** ../coreui/src/views/buttons/ButtonGroups.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ButtonGroups.vue?vue&type=template&id=73dee81e& */ "../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e&");
/* harmony import */ var _ButtonGroups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ButtonGroups.vue?vue&type=script&lang=js& */ "../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _ButtonGroups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/buttons/ButtonGroups.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGroups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./ButtonGroups.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGroups_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e&":
/*!***********************************************************************************!*\
  !*** ../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./ButtonGroups.vue?vue&type=template&id=73dee81e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_ButtonGroups_vue_vue_type_template_id_73dee81e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'ButtonGroups'
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/buttons/ButtonGroups.vue?vue&type=template&id=73dee81e& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "CRow",
    [
      _c(
        "CCol",
        { attrs: { col: "12" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" "),
                  _c("strong", [_vm._v(" Bootstrap button group")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "card-header-actions" }, [
                    _c(
                      "a",
                      {
                        staticClass: "card-header-action",
                        attrs: {
                          href:
                            "https://coreui.io/vue/docs/components/button-components",
                          rel: "noreferrer noopener",
                          target: "_blank"
                        }
                      },
                      [
                        _c("small", { staticClass: "text-muted" }, [
                          _vm._v("docs")
                        ])
                      ]
                    )
                  ])
                ],
                1
              ),
              _vm._v(" "),
              _c("CCardBody", [
                _c(
                  "div",
                  [
                    _c(
                      "CButtonGroup",
                      [
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("One")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Two")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Three")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Four")
                        ]),
                        _vm._v(" "),
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "secondary" }
                          },
                          [_vm._v("Five")]
                        )
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("br"),
                    _c("br"),
                    _vm._v(" "),
                    _c(
                      "CButtonGroup",
                      [
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "success" }
                          },
                          [_vm._v("Success")]
                        ),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "info" } }, [
                          _vm._v("Info")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "warning" } }, [
                          _vm._v("Warn")
                        ]),
                        _vm._v(" "),
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "primary" }
                          },
                          [_vm._v("Primary")]
                        ),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "danger" } }, [
                          _vm._v("Danger")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "link" } }, [
                          _vm._v("Link")
                        ])
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" "),
                  _c("strong", [_vm._v(" Button group ")]),
                  _vm._v("sizing\n      ")
                ],
                1
              ),
              _vm._v(" "),
              _c("CCardBody", [
                _c(
                  "div",
                  [
                    _c(
                      "CButtonGroup",
                      [
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Left")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Middle")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Right")
                        ])
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("br"),
                    _c("br"),
                    _vm._v(" "),
                    _c(
                      "CButtonGroup",
                      { attrs: { size: "sm" } },
                      [
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Left")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Middle")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Right")
                        ])
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("br"),
                    _c("br"),
                    _vm._v(" "),
                    _c(
                      "CButtonGroup",
                      { attrs: { size: "lg" } },
                      [
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Left")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Middle")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Right")
                        ])
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _c("strong", [_vm._v(" Button group ")]),
                  _vm._v("dropdown support\n      ")
                ],
                1
              ),
              _vm._v(" "),
              _c("CCardBody", [
                _c(
                  "div",
                  [
                    _c(
                      "CButtonGroup",
                      [
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "secondary" }
                          },
                          [_vm._v("Button 1")]
                        ),
                        _vm._v(" "),
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "secondary" }
                          },
                          [_vm._v("Button 2")]
                        ),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            attrs: { right: "", text: "Menu", color: "success" }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Item 1")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Item 2")]),
                            _vm._v(" "),
                            _c("CDropdownDivider"),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Item 3")])
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "CButton",
                          {
                            staticClass: "d-sm-down-none",
                            attrs: { color: "secondary" }
                          },
                          [_vm._v("Button 3")]
                        ),
                        _vm._v(" "),
                        _c(
                          "CDropdown",
                          {
                            attrs: {
                              right: "",
                              split: "",
                              text: "Split Menu",
                              color: "info"
                            }
                          },
                          [
                            _c("CDropdownItem", [_vm._v("Item 1")]),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Item 2")]),
                            _vm._v(" "),
                            _c("CDropdownDivider"),
                            _vm._v(" "),
                            _c("CDropdownItem", [_vm._v("Item 3")])
                          ],
                          1
                        )
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" "),
                  _c("strong", [_vm._v(" Button group ")]),
                  _vm._v("vertical variation\n      ")
                ],
                1
              ),
              _vm._v(" "),
              _c("CCardBody", [
                _c(
                  "div",
                  [
                    _c(
                      "CButtonGroup",
                      { attrs: { vertical: "" } },
                      [
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Top")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Middle")
                        ]),
                        _vm._v(" "),
                        _c("CButton", { attrs: { color: "secondary" } }, [
                          _vm._v("Bottom")
                        ])
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" "),
                  _c("strong", [_vm._v(" Button toolbar ")]),
                  _vm._v(" "),
                  _c("small", [_vm._v("with button groups")])
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CCardBody",
                [
                  _c(
                    "CButtonToolbar",
                    { attrs: { "aria-label": "Toolbar with button groups" } },
                    [
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1" },
                        [
                          _c(
                            "CButton",
                            {
                              staticClass: "d-sm-down-none",
                              attrs: { color: "secondary" }
                            },
                            [_vm._v("«")]
                          ),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("‹")
                          ])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1" },
                        [
                          _c(
                            "CButton",
                            {
                              staticClass: "d-sm-down-none",
                              attrs: { color: "secondary" }
                            },
                            [_vm._v("Edit")]
                          ),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Undo")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Redo")
                          ])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1" },
                        [
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("›")
                          ]),
                          _vm._v(" "),
                          _c(
                            "CButton",
                            {
                              staticClass: "d-sm-down-none",
                              attrs: { color: "secondary" }
                            },
                            [_vm._v("»")]
                          )
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("hr", { staticClass: "d-sm-down-none" }),
                  _vm._v(" "),
                  _c(
                    "CButtonToolbar",
                    {
                      staticClass: "d-sm-down-none",
                      attrs: {
                        "aria-label":
                          "Toolbar with button groups and input groups"
                      }
                    },
                    [
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1", attrs: { size: "sm" } },
                        [
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("New")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Edit")
                          ])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("CInput", {
                        staticClass: "mb-0 w-25 mx-1",
                        attrs: {
                          size: "sm",
                          append: ".00",
                          value: "100",
                          prepend: "$"
                        }
                      }),
                      _vm._v(" "),
                      _c("CSelect", {
                        staticClass: "mb-0 w-25 mx-1",
                        attrs: {
                          size: "sm",
                          value: "Medium",
                          options: ["Large", "Medium", "Small"],
                          custom: "",
                          prepend: "Size"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1", attrs: { size: "sm" } },
                        [
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Save")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Cancel")
                          ])
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c("hr"),
                  _vm._v(" "),
                  _c(
                    "CButtonToolbar",
                    {
                      attrs: {
                        "aria-label":
                          "Toolbar with button groups and dropdown menu"
                      }
                    },
                    [
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1 d-sm-down-none" },
                        [
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("New")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Edit")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Undo")
                          ])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CDropdown",
                        {
                          staticClass: "mx-1",
                          attrs: {
                            color: "secondary",
                            placement: "bottom-end",
                            "button-content": "Menu"
                          }
                        },
                        [
                          _c("CDropdownItem", [_vm._v("Item 1")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Item 2")]),
                          _vm._v(" "),
                          _c("CDropdownItem", [_vm._v("Item 3")])
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c(
                        "CButtonGroup",
                        { staticClass: "mx-1" },
                        [
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Save")
                          ]),
                          _vm._v(" "),
                          _c("CButton", { attrs: { color: "secondary" } }, [
                            _vm._v("Cancel")
                          ])
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);