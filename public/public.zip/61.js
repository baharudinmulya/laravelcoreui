(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[61],{

/***/ "../coreui/src/views/notifications/Badges.vue":
/*!****************************************************!*\
  !*** ../coreui/src/views/notifications/Badges.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Badges.vue?vue&type=template&id=dcefe93e&functional=true& */ "../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true&");
/* harmony import */ var _Badges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Badges.vue?vue&type=script&lang=js& */ "../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../laravel/node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_laravel_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Badges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  true,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "coreui/src/views/notifications/Badges.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Badges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/babel-loader/lib??ref--4-0!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Badges.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_laravel_node_modules_babel_loader_lib_index_js_ref_4_0_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Badges_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true&":
/*!***************************************************************************************************!*\
  !*** ../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true& ***!
  \***************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../laravel/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../laravel/node_modules/vue-loader/lib??vue-loader-options!./Badges.vue?vue&type=template&id=dcefe93e&functional=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _laravel_node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_laravel_node_modules_vue_loader_lib_index_js_vue_loader_options_Badges_vue_vue_type_template_id_dcefe93e_functional_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/notifications/Badges.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Badges'
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true&":
/*!*********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!../coreui/src/views/notifications/Badges.vue?vue&type=template&id=dcefe93e&functional=true& ***!
  \*********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function(_h, _vm) {
  var _c = _vm._c
  return _c(
    "CRow",
    [
      _c(
        "CCol",
        { attrs: { col: "12", md: "6" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" "),
                  _c("strong", [_vm._v(" Bootstrap Badge")]),
                  _vm._v(" "),
                  _c("div", { staticClass: "card-header-actions" }, [
                    _c(
                      "a",
                      {
                        staticClass: "card-header-action",
                        attrs: {
                          href: "https://coreui.io/vue/docs/components/badge",
                          rel: "noreferrer noopener",
                          target: "_blank"
                        }
                      },
                      [
                        _c("small", { staticClass: "text-muted" }, [
                          _vm._v("docs")
                        ])
                      ]
                    )
                  ])
                ],
                1
              ),
              _vm._v(" "),
              _c("CCardBody", [
                _c(
                  "h2",
                  [
                    _vm._v("Example heading "),
                    _c("CBadge", { attrs: { color: "primary" } }, [
                      _vm._v("New")
                    ])
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "h3",
                  [
                    _vm._v("Example heading "),
                    _c("CBadge", { attrs: { color: "primary" } }, [
                      _vm._v("New")
                    ])
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "h4",
                  [
                    _vm._v("Example heading "),
                    _c("CBadge", { attrs: { color: "primary" } }, [
                      _vm._v("New")
                    ])
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "h5",
                  [
                    _vm._v("Example heading "),
                    _c("CBadge", { attrs: { color: "primary" } }, [
                      _vm._v("New")
                    ])
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "h6",
                  [
                    _vm._v("Example heading "),
                    _c("CBadge", { attrs: { color: "primary" } }, [
                      _vm._v("New")
                    ])
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c(
                "CCardFooter",
                [
                  _c(
                    "CButton",
                    { attrs: { color: "primary" } },
                    [
                      _vm._v("\n          Notifications\n          "),
                      _c(
                        "CBadge",
                        {
                          staticClass: "ml-2 position-static",
                          attrs: { color: "light" }
                        },
                        [_vm._v("4")]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "CCol",
        { attrs: { col: "12", md: "6" } },
        [
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" Badge\n        "),
                  _c("small", [_vm._v("contextual variations")])
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CCardBody",
                [
                  _c("CBadge", { attrs: { color: "primary" } }, [
                    _vm._v("Primary")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "secondary" } }, [
                    _vm._v("Secondary")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "success" } }, [
                    _vm._v("Success")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "danger" } }, [
                    _vm._v("Danger")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "warning" } }, [
                    _vm._v("Warning")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "info" } }, [_vm._v("Info")]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "light" } }, [
                    _vm._v("Light")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { color: "dark" } }, [_vm._v("Dark")])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" Badge\n        "),
                  _c("small", [_vm._v('shape="pill"')])
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CCardBody",
                [
                  _c("CBadge", { attrs: { shape: "pill", color: "primary" } }, [
                    _vm._v("Primary")
                  ]),
                  _vm._v(" "),
                  _c(
                    "CBadge",
                    { attrs: { shape: "pill", color: "secondary" } },
                    [_vm._v("Secondary")]
                  ),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "success" } }, [
                    _vm._v("Success")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "danger" } }, [
                    _vm._v("Danger")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "warning" } }, [
                    _vm._v("Warning")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "info" } }, [
                    _vm._v("Info")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "light" } }, [
                    _vm._v("Light")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { shape: "pill", color: "dark" } }, [
                    _vm._v("Dark")
                  ])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "CCard",
            [
              _c(
                "CCardHeader",
                [
                  _c("CIcon", { attrs: { name: "cil-justify-center" } }),
                  _vm._v(" Badge\n        "),
                  _c("small", [_vm._v("actionable")])
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "CCardBody",
                [
                  _c("CBadge", { attrs: { href: "#", color: "primary" } }, [
                    _vm._v("Primary")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "secondary" } }, [
                    _vm._v("Secondary")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "success" } }, [
                    _vm._v("Success")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "danger" } }, [
                    _vm._v("Danger")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "warning" } }, [
                    _vm._v("Warning")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "info" } }, [
                    _vm._v("Info")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "light" } }, [
                    _vm._v("Light")
                  ]),
                  _vm._v(" "),
                  _c("CBadge", { attrs: { href: "#", color: "dark" } }, [
                    _vm._v("Dark")
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);