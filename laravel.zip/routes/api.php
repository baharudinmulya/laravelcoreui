<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => 'api'], function ($router) {
    Route::get('menu', 'MenuController@index');

    Route::post('login', 'AuthController@login');
    Route::post('logout', 'AuthController@logout');
    Route::post('refresh', 'AuthController@refresh');
    Route::post('register', 'AuthController@register'); 

    Route::resource('notes', 'NotesController');

    Route::resource('resource/{table}/resource', 'ResourceController');
    
    Route::group(['middleware' => 'admin'], function ($router) {
        
        //KATEGORI
        Route::get('kategori', 'KategoriController@index')->name('kategori.index');
        Route::post('kategori/store', 'KategoriController@store')->name('kategori.store');
        Route::get('kategori/show/{id}', 'KategoriController@show')->name('kategori.show');
        Route::post('kategori/update/{id}', 'KategoriController@update')->name('kategori.update');
        Route::get('kategori/destroy/{id}', 'KategoriController@destroy')->name('kategori.destroy');

        //PRODUK
        Route::get('produk', 'ProdukController@index')->name('produk.index');
        Route::post('produkexcel', 'ProdukController@excel')->name('produk.excel');
        Route::get('produkselect1', 'PesananController@showSelectnamaproduk')->name('pesanan.showSelectnamaproduk');
        Route::get('produkselect2', 'PesananController@showSelectnamapelanggan')->name('pesanan.showSelectnamapelanggan');
        Route::post('produk/store', 'ProdukController@store')->name('produk.store');
        Route::get('produk/show/{id}', 'ProdukController@show')->name('produk.show');
        Route::post('produk/update/{id}', 'ProdukController@update')->name('produk.update');
        Route::get('produk/destroy/{id}', 'ProdukController@destroy')->name('produk.destroy');

        //PESANAN
        Route::get('pesanan', 'PesananController@index')->name('pesanan.index');
        Route::post('pesanan/store', 'PesananController@store')->name('pesanan.store');
        Route::get('pesanan/show/{id}', 'PesananController@show')->name('pesanan.show');
        Route::post('pesanan/update/{id}', 'PesananController@update')->name('pesanan.update');
        Route::post('pesanan/destroy/{id}', 'PesananController@destroy')->name('pesanan.destroy');

        //PELANGGAN
        Route::get('pelanggan', 'PelangganController@index')->name('pelanggan.index');
        Route::post('pelanggan/store', 'PelangganController@store')->name('pelanggan.store');
        Route::post('pelanggan/update/{id}', 'PelangganController@update')->name('pelanggan.update');
        Route::post('pelanggan/delete/{id}', 'PelangganController@destroy')->name('pelanggan.destroy');

        //getLaporan
        Route::get('/laporan/getLaporan', 'LaporanController@index')->name('laporan.index');
        


        // Route::resource('mail',        'MailController');
        // Route::get('prepareSend/{id}', 'MailController@prepareSend')->name('prepareSend');
        // Route::post('mailSend/{id}',   'MailController@send')->name('mailSend');

        // Route::resource('bread',  'BreadController');   //create BREAD (resource)

        // Route::resource('users', 'UsersController')->except( ['create', 'store'] );

        //ROUTE COUNT
        Route::get('omset/keseluruhanomset', 'KeseluruhanomsetController@index')->name('keseluruhanomset.index');
        Route::get('customer/customersa', 'KeseluruhanomsetController@customersa')->name('keseluruhanomset.customersa');
        Route::get('kategori/kategoriproduk', 'KeseluruhanomsetController@kategoriproduk')->name('keseluruhanomset.kategoriproduk');
        Route::get('kategori/jumlahproduk', 'KeseluruhanomsetController@jumlahproduk')->name('keseluruhanomset.jumlahproduk');
        Route::get('order/orderbaru', 'KeseluruhanomsetController@orderbaru')->name('keseluruhanomset.orderbaru');
        Route::get('order/orderproses', 'KeseluruhanomsetController@orderproses')->name('keseluruhanomset.orderproses');
        Route::get('order/orderdikirim', 'KeseluruhanomsetController@orderdikirim')->name('keseluruhanomset.orderdikirim');
        Route::get('order/orderselesai', 'KeseluruhanomsetController@orderselesai')->name('keseluruhanomset.orderselesai');


        Route::prefix('menu/menu')->group(function () { 
            Route::get('/',         'MenuEditController@index')->name('menu.menu.index');
            Route::get('/create',   'MenuEditController@create')->name('menu.menu.create');
            Route::post('/store',   'MenuEditController@store')->name('menu.menu.store');
            Route::get('/edit',     'MenuEditController@edit')->name('menu.menu.edit');
            Route::post('/update',  'MenuEditController@update')->name('menu.menu.update');
            Route::get('/delete',   'MenuEditController@delete')->name('menu.menu.delete');
        });
        // Route::prefix('menu/element')->group(function () { 
        //     Route::get('/',             'MenuElementController@index')->name('menu.index');
        //     Route::get('/move-up',      'MenuElementController@moveUp')->name('menu.up');
        //     Route::get('/move-down',    'MenuElementController@moveDown')->name('menu.down');
        //     Route::get('/create',       'MenuElementController@create')->name('menu.create');
        //     Route::post('/store',       'MenuElementController@store')->name('menu.store');
        //     Route::get('/get-parents',  'MenuElementController@getParents');
        //     Route::get('/edit',         'MenuElementController@edit')->name('menu.edit');
        //     Route::post('/update',      'MenuElementController@update')->name('menu.update');
        //     Route::get('/show',         'MenuElementController@show')->name('menu.show');
        //     Route::get('/delete',       'MenuElementController@delete')->name('menu.delete');
        // });
        Route::prefix('media')->group(function ($router) {
            Route::get('/',                 'MediaController@index')->name('media.folder.index');
            Route::get('/folder/store',     'MediaController@folderAdd')->name('media.folder.add');
            Route::post('/folder/update',   'MediaController@folderUpdate')->name('media.folder.update');
            Route::get('/folder',           'MediaController@folder')->name('media.folder');
            Route::post('/folder/move',     'MediaController@folderMove')->name('media.folder.move');
            Route::post('/folder/delete',   'MediaController@folderDelete')->name('media.folder.delete');;

        //     Route::post('/file/store',      'MediaController@fileAdd')->name('media.file.add');
        //     Route::get('/file',             'MediaController@file');
        //     Route::post('/file/delete',     'MediaController@fileDelete')->name('media.file.delete');
        //     Route::post('/file/update',     'MediaController@fileUpdate')->name('media.file.update');
        //     Route::post('/file/move',       'MediaController@fileMove')->name('media.file.move');
        //     Route::post('/file/cropp',      'MediaController@cropp');
        //     Route::get('/file/copy',        'MediaController@fileCopy')->name('media.file.copy');

        //     Route::get('/file/download',    'MediaController@fileDownload');
        });

        // Route::resource('roles',        'RolesController');
        // Route::get('/roles/move/move-up',      'RolesController@moveUp')->name('roles.up');
        // Route::get('/roles/move/move-down',    'RolesController@moveDown')->name('roles.down');
    });
});

