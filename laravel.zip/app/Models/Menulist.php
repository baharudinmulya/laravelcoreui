<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menulist extends Model
{
    protected $table = 'menulist';
    public $timestamps = false; 
}
